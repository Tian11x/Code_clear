clear;clc;
%===============================Data Read===================================%
data=load('PlanetLabData.mat');
X=data.data; 
X=X./max(max(max(X)));  % Data normalization
%=========================================================================%
R=30; %rank 
W=9; %window 
alpha=0.7; %alpha
%=========================================================================%
RSE=[];
MAE=[];

for ratio=0.05:0.05:0.95 %sample rate
    [rse,mae]=Performance_evaluation(X,ratio,alpha,W,R);
    RSE=[RSE,rse];
    MAE=[MAE,mae];
end

Result.RSE=RSE;
Result.MAE=MAE;

