function [X_rec,A,B,C]=inferring_scheme_accelerate(X,IDX,Aold,Bold,Cold,alpha)
%============================================================%
[I,J,K]=size(X);
[~,R]=size(Aold);
XT=X(:,:,K); 
XT=XT(:);
row=find(XT~=0);
KR=KR_product(Bold,Aold);
Tmp=KR(row,:);
XT=XT(row,:);
c=(Tmp' * Tmp + 0.01*eye(R,R)) \ ( Tmp'*XT );  %  update c
C=[Cold(2:K,:);c'];

[A,B,C]=my_cp_als_initial_with_weight(X.*IDX,Aold,Bold,C,R,0.01,1,alpha);
X_rec=tensor_inner_fast(A,B,C);
end