function [A,B,C]=my_cp_als(S,IDX,R,lambda,threshold)
%=============================================================%
[I,J,K]=size(S);
S1=double( tenmat(S,1) ); S2=double( tenmat(S,2) ); S3=double( tenmat(S,3) );
IDX1=double( tenmat(IDX,1) ); IDX2=double( tenmat(IDX,2) ); IDX3=double( tenmat(IDX,3) );
%===============================%
maxItr=20;
tol = 1e-5;
converge = false;
old_error=0;
it=1;
A=rand(I,R); B=rand(J,R); C=rand(K,R);  

while ~converge
    CB=KR_product(C,B); 
    for i=1:I
        value=S1(i,:);     
        idx=IDX1(i,:);          
        [~,col]=find(idx~=0);
        value=value(:,col);
        cb=CB(col,:);  
        Q = (cb'*cb + lambda * eye(R,R) ) \ ( cb' * value' );
        if norm(Q)<threshold
           A(i,:) = Q;
        end     
    end
   
    CA=KR_product(C,A); % 
    for j=1:J
        value=S2(j,:);      %
        idx=IDX2(j,:);   %      
        [~,col]=find(idx~=0);
        value=value(:,col);
        ca=CA(col,:);    %
        Q = (ca'*ca + lambda * eye(R,R) ) \ ( ca' * value' );
        if norm(Q)<threshold
           B(j,:) = Q;
        end 
    end
    BA=KR_product(B,A); 
    for k=1:K
        value=S3(k,:);     
        idx=IDX3(k,:);         
        [~,col]=find(idx~=0);
        value=value(:,col);
        ba=BA(col,:);    
        Q = (ba'*ba + lambda * eye(R,R) ) \ ( ba' * value' );
        if norm(Q)<threshold
           C(k,:) = Q;
        end 
    end
    S_recover=tensor_inner_fast(A,B,C);  
    [train_error,~]=tensor_recover_error(S,S_recover,IDX); 
    if it >= maxItr || abs(old_error - train_error) < tol
        converge = true;
    end
    old_error=train_error;
    it = it+1;
end   
