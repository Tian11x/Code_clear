function [RSE,MAE]=Performance_evaluation(X,ratio,alpha,W,R)
%====================================================================%
[I,J,K]=size(X);
Xold=X(:,:,1:W); %previous window
IDXold=ones(size(Xold)); %previous sample location
number=I*J*ratio;  %sample number
X_hat=zeros(size(X)); X_hat(:,:,1:W)=Xold;  %X_hat is recovered tensor
IDX=zeros(size(X));IDX(:,:,1:W)=IDXold;     
[Aold,Bold,Cold]=my_cp_als(Xold,ones(size(Xold)),R,0.01,10); % previous window 
Mcom=X(:,:,1:W-1); MT=X(:,:,W); Ccom=Cold(1:W-1,:); CT=Cold(W,:);
Mcom1=double( tenmat(Mcom,1) ); Mcom2=double( tenmat(Mcom,2) );
MT1=double( tenmat(MT,1) ); MT2=double( tenmat(MT,2) );
CcomA=KR_product(Ccom,Aold); CcomB=KR_product(Ccom,Bold);
CTA=KR_product(CT,Aold);CTB=KR_product(CT,Bold);
ToldA1=(1-alpha)*(Mcom1)*(CcomB)+alpha*(MT1)*(CTB);
ToldA2=(1-alpha)*(CcomB)'*(CcomB)+alpha*(CTB)'*(CTB);
ToldB1=(1-alpha)*(Mcom2)*(CcomA)+alpha*(MT2)*(CTA);
ToldB2=(1-alpha)*(CcomA)'*(CcomA)+alpha*(CTA)'*(CTA);

for k=W+1:K
    Xcur=zeros(I,J,W);      %current window
    IDXcur=zeros(I,J,W);    % 
    Xcom=Xold(:,:,2:W);     % common window
    IDXcom=IDXold(:,:,2:W); % common window's sample location
    Xcur(:,:,1:W-1)=Xcom;   % update current window
    IDXcur(:,:,1:W-1)=IDXcom; % 
    [Index]=sampling_scheme_accelerate( Aold,Bold,number ); %sampling scheduling
    IDXcur(:,:,W)=Index;  % Update
    IDX(:,:,k)=Index;     % Update
    Xcur(:,:,W)=X(:,:,k).*Index;  % 
    [Xrec,Aold,Bold,Cold]=inferring_scheme_accelerate(Xcur,IDXcur,Aold,Bold,Cold,alpha); 
%     [Cold]=updateC(Xcur,IDX,Aold,Bold,Cold,alpha);
%     [Aold,ToldA1,ToldA2]=updateA(Xcur,alpha,ToldA1,ToldA2,Aold,Bold,Cold);
%     [Bold,ToldB1,ToldB2]=updateB(Xcur,alpha,ToldB1,ToldB2,Aold,Bold,Cold); 
    Xrec=tensor_inner_fast(Aold,Bold,Cold);
    X_hat(:,:,k)=Xrec(:,:,W);   
    Xold=Xcur;    
    IDXold=IDXcur; 
end
X_hat=X.*IDX+X_hat.*(1-IDX);
%============calculate the RSE and MAE============%
Xhatx=X_hat(:,:,W+1:K);
Xx=X(:,:,W+1:K);
Kx=K-W+1;
RSE=sqrt(   sum(sum(sum(  ( Xhatx-Xx ).^2 ))) / sum(sum(sum( Xx.^2 )))    );
MAE = sum(sum( sum(abs(Xhatx-Xx))))/(I*J*Kx);