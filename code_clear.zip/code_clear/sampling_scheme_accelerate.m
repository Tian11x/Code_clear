function [Index] =sampling_scheme_accelerate(A,B,number)
%=======================================================%

[I,R]=size(A);[J,~]=size(B); 
R=min(I,R); R=min(J,R);
[UA,~,~]=svd(A); [UB,~,~]=svd(B);
if number>I*J
    number=I*J;
end
%=========row leverage score===============%
La=zeros(1,I);      Lb=zeros(1,J);
for i=1:I
    La(i)=norm(UA(i,1:R),'Fro');
end

for i=1:J
    Lb(i)=norm(UB(i,1:R),'Fro');
end
LA=[1:I;La];LA=LA';
LB=[1:J;Lb];LB=LB';
%=======================================%
LA=sortrows(LA,2,'descend');
LB=sortrows(LB,2,'descend');%

H=max(I,J);L=min(I,J);

Index=zeros(H,L);
index=zeros(H,L);
if I<J
    LC=LA;
    LA=LB;
    LB=LC;
end
Layer=zeros(I+J-1,1);
for i=1:I+J-1
    if( i<=L )      % 
        Layer(i)=i;
    elseif i-L<=H-L % 
        Layer(i)=L;
    else
        Layer(i)=I+J-i;  %
    end     
end

ind=1; tmp=number; 
flag=0;
while tmp>=0
    if tmp==0
        flag=1; 
        break;
    end
    tmp = tmp-Layer(ind) ;
    ind=ind+1;  
end
ind=ind-1;
P=[];
if flag==0
    Ind=ind-1; %
    layer=ind; %
    if layer<=L 
        for row=1:layer
            col=layer-row+1;
            p=LA(row,2)*LB(col,2);%
            pro=[row,col,p];
            P=[P;pro];
        end
    elseif layer-L<=H-L
        for row=layer-L+1:layer
            col=layer-row+1;
            p=LA(row,2)*LB(col,2);%
            pro=[row,col,p];
            P=[P;pro];
        end 
    else
        for row=I-(H+L-1-layer):I
            col=layer-row+1;
            p=LA(row,2)*LB(col,2);%
            pro=[row,col,p];
            P=[P;pro];
        end
    end   
    P=sortrows(P,3,'descend'); %
    num=number-sum(Layer(1:Ind));
    for i=1:num
        row=P(i,1);
        col=P(i,2);
        index(row,col)=1;
        Index(LA(row,1),LB(col,1))=1;
    end
else 
    Ind=ind;   %
end

for layer=1:Ind %
    if layer<=L 
        for row=1:layer
            col=layer-row+1;
            index(row,col)=1;
            Index(LA(row,1),LB(col,1))=1;
        end
    elseif layer-L<=H-L
        for row=layer-L+1:layer
            col=layer-row+1;
            index(row,col)=1;
            Index(LA(row,1),LB(col,1))=1;
        end 
    else
        for row=H-(H+L-1-layer):H
            col=layer-row+1;
            index(row,col)=1;
            Index(LA(row,1),LB(col,1))=1;
        end
    end        
end

if I<J
    Index=Index';
end

end

