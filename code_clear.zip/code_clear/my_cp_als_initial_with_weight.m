function [A,B,C]=my_cp_als_initial_with_weight(M,A,B,C,R,lambda,threshold,alpha)
%===========================================================================%

[I,J,K]=size(M);
IDX=(M~=0);%
Mcom=M(:,:,1:K-1); Mt=M(:,:,K);
Mcom1=double( tenmat(Mcom,1) ); Mcom2=double( tenmat(Mcom,2) ); M3=double( tenmat(M,3) );
Mt1=double( tenmat(Mt,1) ); Mt2=double( tenmat(Mt,2) ); 

maxItr=1;
tol = 1e-5; 
converge = false; 
old_error=0;
it=1;

while ~converge
    Ccom=C(1:K-1,:);      
    Ct=C(K,:);            
    CBcom=KR_product(Ccom,B); 
    CBt=KR_product(Ct,B);     
    for i=1:I
        Mcom1i=Mcom1(i,:);      
        Mt1i=Mt1(i,:);             
        [~,col1]=find(Mcom1i~=0); 
        [~,col2]=find(Mt1i~=0);   
        Vcom=Mcom1i(:,col1);      
        Vt=Mt1i(:,col2);
        CB1=CBcom(col1,:); 
        CB2=CBt(col2,:);      
        Q=( (1-alpha)*CB1'*CB1 + alpha*CB2'*CB2 + lambda * eye(R,R) ) \ ( (1-alpha)*CB1'*Vcom' + alpha*CB2'*Vt' );
        
        if norm(Q)<threshold
           A(i,:) = Q;
        end     
    end
 
    CAcom=KR_product(Ccom,A); 
    CAt=KR_product(Ct,A); 
    for j=1:J
        Mcom2j=Mcom2(j,:);     
        Mt2i=Mt2(j,:);    
        [~,col1]=find(Mcom2j~=0);
        [~,col2]=find(Mt2i~=0);
        Vcom=Mcom2j(:,col1);
        Vt=Mt2i(:,col2);
        CA1=CAcom(col1,:);    
        CA2=CAt(col2,:);
        Q=( (1-alpha)*CA1'*CA1 + alpha*CA2'*CA2 + lambda * eye(R,R) ) \ ( (1-alpha)*CA1'*Vcom' + alpha*CA2'*Vt' );
        if norm(Q)<threshold
           B(j,:) = Q;
        end 
    end
    BA=KR_product(B,A); % 
    for k=1:K
        value=M3(k,:);       
        [~,col]=find(value~=0);
        value=value(:,col);
        ba=BA(col,:);    
        Q = (ba'*ba + lambda * eye(R,R) ) \ ( ba' * value' );
        if norm(Q)<threshold
           C(k,:) = Q;
        end 
    end

    M_recover=tensor_inner_fast(A,B,C);  
    [train_error,~]=tensor_recover_error(M,M_recover,IDX); %
    disp(['the train error in ',int2str(it-1),'-th iteration is:',num2str(train_error)]);
    if it >= maxItr || abs(old_error - train_error) < tol
        converge = true;
    end
    old_error=train_error;
    it = it+1;
end   
